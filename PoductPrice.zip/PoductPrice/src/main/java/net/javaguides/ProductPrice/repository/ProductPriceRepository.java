package net.javaguides.ProductPrice.repository;

import net.javaguides.ProductPrice.model.ProductPrice;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProductPriceRepository extends JpaRepository<ProductPrice,Long> {
    // all crud database method
}

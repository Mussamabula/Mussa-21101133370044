package net.javaguides.ProductPrice.controller;

import net.javaguides.ProductPrice.exception.ResourceNotFoundException;
import net.javaguides.ProductPrice.model.ProductPrice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/api/v1/ProductPrice")

public class ProductPriceController {

    @Autowired
    private net.javaguides.ProductPrice.repository.ProductPriceRepository ProductPriceRepository;

    @GetMapping
    public List<net.javaguides.ProductPrice.model.ProductPrice> getAllSuppliers(){
        return ProductPriceRepository.findAll();
    }


    // build create PRODUCT REST API
    @PostMapping
    public ProductPrice createSupplier(@RequestBody ProductPrice ProductPrice){
        return ProductPriceRepository.save(ProductPrice);
    }

    // build get product price  by id REST API
    @GetMapping("{id}")
    public ResponseEntity<ProductPrice> getSupplierById(@PathVariable long id){
        ProductPrice ProductPrice = ProductPriceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not exist with id:" + id));
        return  ResponseEntity.ok(ProductPrice);
    }
    // build update PRODUCT REST API
    @PutMapping("{id}")
    public ResponseEntity<ProductPrice> updateSupplier(@PathVariable long id, @RequestBody ProductPrice ProductPriceDetails) {
        ProductPrice updateProductPrice = ProductPriceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not exist with id:" + id));

        updateProductPrice.setProductPrice(ProductPriceDetails.getProductPrice());
        updateProductPrice.setProductName(ProductPriceDetails.getProductName());


        ProductPriceRepository.save(updateProductPrice);
        return ResponseEntity.ok(updateProductPrice);
    }
    // build delete PRODUCT REST API
    @DeleteMapping("{id}")
    public ResponseEntity<HttpStatus> deleteSupplier(@PathVariable long id){
        ProductPrice productPrice = ProductPriceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not exist with id:" + id));

        ProductPriceRepository.delete(productPrice);

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


}

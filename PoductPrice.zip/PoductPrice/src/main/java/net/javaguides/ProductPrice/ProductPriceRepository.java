package net.javaguides.ProductPrice;

import net.javaguides.ProductPrice.model.ProductPrice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductPriceRepository implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(net.javaguides.ProductPrice.repository.ProductPriceRepository.class, args);
	}

	@Autowired
	private net.javaguides.ProductPrice.repository.ProductPriceRepository ProductPriceRepository;
	@Override
	public void run(String... args) throws Exception {
		ProductPrice ProductPrice = new ProductPrice();
		ProductPrice.setProductName("Clothes");
		ProductPrice.setProductPrice(10000);
		ProductPrice.save(ProductPrice);

		ProductPrice ProductPrice1 = new ProductPrice();
		ProductPrice1.setProductPrice(20000);
		ProductPrice1.setProductName("SmartPhones");
		ProductPrice1.save(ProductPrice);

	}
}

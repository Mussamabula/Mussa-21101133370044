package net.javaguides.ProductPrice.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity()
@Table(name = "ProductPrice")
public class ProductPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "ProductName")
    private String ProductName;

    @Column(name = "ProductPrice")
    private int ProductPrice;

    public void save(net.javaguides.ProductPrice.model.ProductPrice productPrice) {

    }
}

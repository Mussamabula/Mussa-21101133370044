package net.javaguides.ProductPrice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductPrice {

	@Test
	void contextLoads() {
	}

}
